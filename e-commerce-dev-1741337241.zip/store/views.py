from django.shortcuts import render
from rest_framework.viewsets import ModelViewSet
from . import models
from . import serializers
from rest_framework.decorators import api_view
from rest_framework.response import Response
import os

class ProductView(ModelViewSet):
    queryset = models.Product.objects.all()
    serializer_class = serializers.ProductSerializer

@api_view(['GET'])
def temp_view(request):
    return Response({'message': str(os.getenv('DB_HOST'))})